--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: hostel; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hostel;


ALTER SCHEMA hostel OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: example_procedure(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.example_procedure()
    LANGUAGE plpgsql
    AS $$
DECLARE result TEXT;
DECLARE err_state TEXT; err_message TEXT; err_detail TEXT; err_hint TEXT; err_context TEXT;
BEGIN
	
	result := (1 + 5);
	
	RAISE NOTICE 'RESULT : %',result;
	
EXCEPTION
    WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS err_state = RETURNED_SQLSTATE,
                            err_message = MESSAGE_TEXT,
                            err_detail = PG_EXCEPTION_DETAIL,
                            err_hint = PG_EXCEPTION_HINT,
                            err_context = PG_EXCEPTION_CONTEXT;
        -- Handle the exception
        RAISE WARNING 'An error occurred: %', SQLERRM;
        result := NULL; -- Or handle the error in an appropriate way
END;
$$;


ALTER PROCEDURE public.example_procedure() OWNER TO postgres;

--
-- Name: fn_get_hostellers(text, text, text, text, integer, integer, boolean, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_get_hostellers(in_full_name text DEFAULT ''::text, in_email_id text DEFAULT ''::text, in_sort_by text DEFAULT 'hosteller_id'::text, in_sort_order text DEFAULT 'desc'::text, in_page_number integer DEFAULT 1, in_page_size integer DEFAULT 5, in_is_export boolean DEFAULT false, clf_full_name text DEFAULT ''::text) RETURNS TABLE(hosteller_id bigint, full_name character varying, email_id character varying, phone_number character varying, dob date, fee numeric, joining_date timestamp without time zone, address text, proof text, reason character varying, vacated_date timestamp without time zone, active boolean, total_count bigint)
    LANGUAGE plpgsql
    AS $_$

/***

-- Author	  :	Ch Sathish Kumar
-- Create date: 11-04-2024
-- Description:	get hostel data

-- EXEC SCRIPT : select * from public.fn_get_hostellers('', '', '', '', 1, 25, false, '')

***/

DECLARE dynamic_sql TEXT;
DECLARE err_state TEXT; err_message TEXT; err_detail TEXT; err_hint TEXT; err_conTEXT TEXT;
BEGIN

	DROP TABLE IF EXISTS temp_hostel_data;
	
	CREATE TEMPORARY TABLE temp_hostel_data ON COMMIT DROP AS
    	SELECT h.hosteller_id,h.full_name, h.email_id,
		h.phone_number,h.dob,
		h.fee,h.joining_date ,
		h.address ,h.proof ,h.reason ,
		h.vacated_date ,h.active
		FROM hostel.hostellers h
		WHERE (h.full_name ILIKE in_full_name||'%' OR in_full_name ='')
		AND (h.email_id ILIKE in_email_id||'%' OR in_email_id ='');
		
	dynamic_sql := 'select *,COUNT(1) OVER() AS total_count
				FROM temp_hostel_data WHERE 1=1';
	
	IF COALESCE(clf_full_name , '') <> '' THEN
		dynamic_sql := dynamic_sql || ' AND full_name ilike $1 ';
		END IF;
	
	dynamic_sql := dynamic_sql || ' ORDER BY ' ||
		CASE 
			WHEN in_sort_by = '' THEN 'full_name'
			ELSE in_sort_by
			END || CASE WHEN in_sort_order='asc' THEN ' asc NULLS FIRST' ELSE ' desc NULLS LAST' END;
			
	IF COALESCE(in_is_export,'false') ='false' THEN
		dynamic_sql := dynamic_sql ||' LIMIT $2 OFFSET ($3 - 1) * $2';
	END IF;
	
	RAISE NOTICE 'Generated SQL Statement: %', dynamic_sql;
	
	RETURN QUERY EXECUTE dynamic_sql USING clf_full_name||'%',in_page_size,in_page_number;

EXCEPTION
    -- Catch any SQL errors and raise a NOTICE with the error message
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS err_state = RETURNED_SQLSTATE,
                            err_message = MESSAGE_TEXT,
                            err_detail = PG_EXCEPTION_DETAIL,
                            err_hint = PG_EXCEPTION_HINT,
                            err_context = PG_EXCEPTION_CONTEXT;
        -- Raise a notice with the error message and stacked diagnostics
        RAISE WARNING 'An error occurred while executing dynamic SQL>>>>  SQLSTATE: %.  Message: %. Detail: %. Hint: %. ConTEXT: %',
                        err_state, err_message, err_detail, err_hint, err_context;
		--INSERT INTO public.error_logs(object_name, object_type, err_state,err_message,err_detail,err_hint,err_context)
		--VALUES ('public.get_employee_data','FUNCTION', err_state,err_message,err_detail,err_hint,err_context);
        RETURN;

END;
$_$;


ALTER FUNCTION public.fn_get_hostellers(in_full_name text, in_email_id text, in_sort_by text, in_sort_order text, in_page_number integer, in_page_size integer, in_is_export boolean, clf_full_name text) OWNER TO postgres;

--
-- Name: fn_get_hostellers_sk(text, text, text, text, integer, integer, boolean, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_get_hostellers_sk(in_full_name text DEFAULT ''::text, in_email_id text DEFAULT ''::text, in_sort_by text DEFAULT 'hosteller_id'::text, in_sort_order text DEFAULT 'desc'::text, in_page_number integer DEFAULT 1, in_page_size integer DEFAULT 5, in_is_export boolean DEFAULT false, clf_full_name text DEFAULT ''::text, clf_joining_date text DEFAULT ''::text) RETURNS TABLE(hosteller_id bigint, full_name character varying, email_id character varying, phone_number character varying, dob date, fee numeric, joining_date text, address text, proof text, reason character varying, vacated_date timestamp without time zone, active boolean, total_count bigint)
    LANGUAGE plpgsql
    AS $_$

/***

-- Author	  :	Ch Sathish Kumar
-- Create date: 11-04-2024
-- Description:	get hostel data

-- EXEC SCRIPT : select * from public.fn_get_hostellers_sk('', '', '', '', 1, 25, false, '','')

***/

DECLARE dynamic_sql TEXT;
DECLARE err_state TEXT; err_message TEXT; err_detail TEXT; err_hint TEXT; err_conTEXT TEXT;
BEGIN

	DROP TABLE IF EXISTS temp_hostel_data;
	
	CREATE TEMPORARY TABLE temp_hostel_data ON COMMIT DROP AS
    	SELECT h.hosteller_id,h.full_name, h.email_id,
		h.phone_number,h.dob,
		h.fee,
		h.joining_date,
		h.address ,h.proof ,h.reason ,
		h.vacated_date ,h.active
		FROM hostel.hostellers h
		WHERE (h.full_name ILIKE in_full_name||'%' OR in_full_name ='')
		AND (h.email_id ILIKE in_email_id||'%' OR in_email_id ='');
		
dynamic_sql := 'SELECT 
	    hosteller_id, full_name, email_id,
	    phone_number, dob,
	    fee,
	    TO_CHAR(joining_date, ''MM/DD/YYYY'') AS formatted_joining_date,
	    address, proof, reason,
	    vacated_date, active,
	    COUNT(1) OVER() AS total_count
	FROM temp_hostel_data WHERE 1=1';
	
	IF COALESCE(clf_full_name , '') <> '' THEN
		dynamic_sql := dynamic_sql || ' AND full_name ilike $1 ';
	END IF;

	IF COALESCE(clf_joining_date , '') <> '' THEN
		dynamic_sql := dynamic_sql || ' AND joining_date::date = $4::date ';
	END IF;
	
	dynamic_sql := dynamic_sql || ' ORDER BY ' ||
		CASE 
			WHEN in_sort_by = '' THEN 'full_name'
			ELSE in_sort_by
			END || CASE WHEN in_sort_order='asc' THEN ' asc NULLS FIRST' ELSE ' desc NULLS LAST' END;
			
	IF COALESCE(in_is_export,'false') ='false' THEN
		dynamic_sql := dynamic_sql ||' LIMIT $2 OFFSET ($3 - 1) * $2';
	END IF;
	
	RAISE NOTICE 'Generated SQL Statement: %', dynamic_sql;
	
	RETURN QUERY EXECUTE dynamic_sql USING clf_full_name||'%',in_page_size,in_page_number,
		clf_joining_date;

EXCEPTION
    -- Catch any SQL errors and raise a NOTICE with the error message
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS err_state = RETURNED_SQLSTATE,
                            err_message = MESSAGE_TEXT,
                            err_detail = PG_EXCEPTION_DETAIL,
                            err_hint = PG_EXCEPTION_HINT,
                            err_context = PG_EXCEPTION_CONTEXT;
        -- Raise a notice with the error message and stacked diagnostics
        RAISE WARNING 'An error occurred while executing dynamic SQL>>>>  SQLSTATE: %.  Message: %. Detail: %. Hint: %. ConTEXT: %',
                        err_state, err_message, err_detail, err_hint, err_context;
		--INSERT INTO public.error_logs(object_name, object_type, err_state,err_message,err_detail,err_hint,err_context)
		--VALUES ('public.get_employee_data','FUNCTION', err_state,err_message,err_detail,err_hint,err_context);
        RETURN;

END;
$_$;


ALTER FUNCTION public.fn_get_hostellers_sk(in_full_name text, in_email_id text, in_sort_by text, in_sort_order text, in_page_number integer, in_page_size integer, in_is_export boolean, clf_full_name text, clf_joining_date text) OWNER TO postgres;

--
-- Name: fn_get_hostellers_sk1(text, text, text, text, integer, integer, boolean, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_get_hostellers_sk1(in_full_name text DEFAULT ''::text, in_email_id text DEFAULT ''::text, in_sort_by text DEFAULT 'hosteller_id'::text, in_sort_order text DEFAULT 'desc'::text, in_page_number integer DEFAULT 1, in_page_size integer DEFAULT 5, in_is_export boolean DEFAULT false, clf_full_name text DEFAULT ''::text, clf_joining_date text DEFAULT ''::text) RETURNS TABLE(hosteller_id bigint, full_name character varying, email_id character varying, phone_number character varying, dob date, fee numeric, joining_date text, address text, proof text, reason character varying, vacated_date timestamp without time zone, active boolean, total_count bigint)
    LANGUAGE plpgsql
    AS $_$

/***

-- Author	  :	Ch Sathish Kumar
-- Create date: 11-04-2024
-- Description:	get hostel data

-- EXEC SCRIPT : select * from public.fn_get_hostellers_sk1('', '', '', '', 1, 25, false, '','09/22/2296')

***/

DECLARE dynamic_sql TEXT;
DECLARE err_state TEXT; err_message TEXT; err_detail TEXT; err_hint TEXT; err_conTEXT TEXT;
BEGIN

	DROP TABLE IF EXISTS temp_hostel_data;
	/*
	CREATE TEMPORARY TABLE temp_hostel_data ON COMMIT DROP AS
    	SELECT h.hosteller_id,h.full_name, h.email_id,
		h.phone_number,h.dob,h.fee,
		h.joining_date,
		h.address ,h.proof ,h.reason ,h.vacated_date ,h.active
		FROM hostel.hostellers h
		WHERE (h.full_name ILIKE in_full_name||'%' OR in_full_name ='')
		AND (h.email_id ILIKE in_email_id||'%' OR in_email_id ='');*/
		
dynamic_sql := 'SELECT h.hosteller_id, h.full_name, h.email_id, 
                       h.phone_number, h.dob, h.fee,
                       TO_CHAR(h.joining_date, ''MM/DD/YYYY'') AS formatted_joining_date,
                       h.address, h.proof, h.reason, h.vacated_date, h.active,
                       COUNT(1) OVER() AS total_count
                FROM hostel.hostellers h
                WHERE ($5 IS NULL OR h.full_name ILIKE $5 || ''%'')
                  AND ($6 IS NULL OR h.email_id ILIKE $6 || ''%'')';
	
	IF COALESCE(clf_full_name , '') <> '' THEN
		dynamic_sql := dynamic_sql || ' AND full_name ilike $1 ';
	END IF;

	IF COALESCE(clf_joining_date , '') <> '' THEN
		dynamic_sql := dynamic_sql || ' AND joining_date::date = TO_DATE($4,''MM/dd/yyyy'') ';
	END IF;
	
	dynamic_sql := dynamic_sql || ' ORDER BY ' ||
		CASE 
			WHEN in_sort_by = '' THEN 'full_name'
			ELSE in_sort_by
			END || CASE WHEN in_sort_order='asc' THEN ' asc NULLS FIRST' ELSE ' desc NULLS LAST' END;
			
	IF COALESCE(in_is_export,'false') ='false' THEN
		dynamic_sql := dynamic_sql ||' LIMIT $2 OFFSET ($3 - 1) * $2';
	END IF;
	
	RAISE NOTICE 'Generated SQL Statement: %', dynamic_sql;
	
	RETURN QUERY EXECUTE dynamic_sql USING clf_full_name||'%',in_page_size,in_page_number,
		clf_joining_date,in_full_name,in_email_id;

EXCEPTION
    -- Catch any SQL errors and raise a NOTICE with the error message
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS err_state = RETURNED_SQLSTATE,
                            err_message = MESSAGE_TEXT,
                            err_detail = PG_EXCEPTION_DETAIL,
                            err_hint = PG_EXCEPTION_HINT,
                            err_context = PG_EXCEPTION_CONTEXT;
        -- Raise a notice with the error message and stacked diagnostics
        RAISE WARNING 'An error occurred while executing dynamic SQL>>>>  SQLSTATE: %.  Message: %. Detail: %. Hint: %. ConTEXT: %',
                        err_state, err_message, err_detail, err_hint, err_context;
		--INSERT INTO public.error_logs(object_name, object_type, err_state,err_message,err_detail,err_hint,err_context)
		--VALUES ('public.get_employee_data','FUNCTION', err_state,err_message,err_detail,err_hint,err_context);
        RETURN;

END;
$_$;


ALTER FUNCTION public.fn_get_hostellers_sk1(in_full_name text, in_email_id text, in_sort_by text, in_sort_order text, in_page_number integer, in_page_size integer, in_is_export boolean, clf_full_name text, clf_joining_date text) OWNER TO postgres;

--
-- Name: fn_insert_user_with_details(text, text, text, text, text, text, text, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_insert_user_with_details(in_first_name text, in_last_name text, in_email_id text, in_phone_number text, in_dob text, in_role_name text, in_active text, in_uploaded_by_id bigint) RETURNS TABLE(insrted_new_user_id bigint)
    LANGUAGE plpgsql
    AS $$
/***

-- Author	  :	Ch Sathish Kumar
-- Create date: 24-08-2024
-- Description:	insert user details

-- EXEC SCRIPT : select * from public.fn_insert_user_with_details
	(text, text, text, text, text, text, bigint)

***/
DECLARE err_state TEXT; err_message TEXT; err_detail TEXT; err_hint TEXT; err_context TEXT;
DECLARE
    new_user_id BIGINT; in_role_id BIGINT;
BEGIN
	
	-- Insert into users table
    INSERT INTO hostel.users (
        first_name, last_name, email_id, password_salt, phone_number, dob, mail_uuid, user_uuid, is_active, 
        last_login_date, last_password_reset_date, created_by_id, created_date, modified_by_id, modified_date
    )
    VALUES (
        in_first_name, in_last_name, in_email_id, NULL, in_phone_number,TO_DATE(in_dob, 'DDMMYYYY'), NULL,
		CONCAT(uuid_generate_v4(),'#',(EXTRACT(EPOCH FROM NOW()) * 1000)::BIGINT),
		CASE WHEN in_active = 'Yes' THEN true ELSE false END,
		NULL, NULL, in_uploaded_by_id, now(), in_uploaded_by_id, now()
    )
    RETURNING user_id INTO new_user_id;

	--Get the role_id from in_role_name
	SELECT role_id FROM hostel.roles WHERE role_name = in_role_name INTO in_role_id;

    -- Insert into user_roles table
    INSERT INTO hostel.user_roles (
        user_id, role_id, is_active, created_by_id, created_date, modified_by_id, modified_date
    )
    VALUES (
        new_user_id, in_role_id,true, in_uploaded_by_id, now(), in_uploaded_by_id, now()
    );

  -- Insert into user_privileges table
    INSERT INTO hostel.user_privileges (
        user_id, resource_id, read_only_flag, read_write_flag, terminate_flag, is_active, 
        created_by_id, created_date, modified_by_id, modified_date
    )
   SELECT 
        new_user_id, rp.resource_id, rp.read_only_flag, rp.read_write_flag, rp.terminate_flag, 
        true, in_uploaded_by_id, now(), in_uploaded_by_id, now()
    FROM hostel.role_privileges rp
    WHERE rp.role_id = in_role_id;
	
	RAISE NOTICE 'RESULT : %',new_user_id;

	RETURN QUERY SELECT new_user_id;
	
EXCEPTION
    WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS err_state = RETURNED_SQLSTATE,
                            err_message = MESSAGE_TEXT,
                            err_detail = PG_EXCEPTION_DETAIL,
                            err_hint = PG_EXCEPTION_HINT,
                            err_context = PG_EXCEPTION_CONTEXT;
        -- Handle the exception
        RAISE WARNING 'An error occurred: %', SQLERRM;
END;
$$;


ALTER FUNCTION public.fn_insert_user_with_details(in_first_name text, in_last_name text, in_email_id text, in_phone_number text, in_dob text, in_role_name text, in_active text, in_uploaded_by_id bigint) OWNER TO postgres;

--
-- Name: fn_validate_users_stg(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_validate_users_stg(in_upload_file_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $_$
DECLARE
    rec RECORD;
    email_pattern CONSTANT TEXT := '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$';
    dob_pattern CONSTANT TEXT := '^\d{4}-\d{2}-\d{2}$';
    phone_number_pattern CONSTANT TEXT := '^\d{10}$';
    final_status TEXT;
    final_error_message TEXT;
	new_user_id BIGINT;
	success_count BIGINT;
	failure_count BIGINT;
BEGIN
    FOR rec IN SELECT * FROM users_stg WHERE upload_file_id = in_upload_file_id 
						AND status IS NULL	LOOP
        -- Initialize status and error message
        final_status := 'success';
        final_error_message := '';

        -- Check if the email is valid
        IF rec.email_id !~* email_pattern THEN
            final_status := 'fail';
            final_error_message := final_error_message || 'Invalid email format, ';
        END IF;

        -- Check if the email exists in the users table
        IF EXISTS (SELECT 1 FROM hostel.users u WHERE u.email_id = rec.email_id) THEN
            final_status := 'fail';
            final_error_message := final_error_message || 'Email already exists, ';
        END IF;

        -- Check if the dob is in yyyy-MM-dd format
        IF rec.dob !~* dob_pattern THEN
            final_status := 'fail';
            final_error_message := final_error_message || 'Invalid dob format, ';
        END IF;

        -- Check if the phone number is valid
        IF rec.phone_number !~* phone_number_pattern THEN
            final_status := 'fail';
            final_error_message := final_error_message || 'Invalid phone number format, ';
        END IF;

        -- Remove trailing comma and space from error_message
        final_error_message := TRIM(BOTH ' ,' FROM final_error_message);

		--Insert into main table
		IF final_status = 'success' THEN
			SELECT fn.insrted_new_user_id INTO new_user_id FROM fn_insert_user_with_details(
			rec.first_name,rec.last_name,rec.email_id,rec.phone_number,
			rec.dob,rec.role_name) fn;
		END IF;

        -- Update the users_stg table
        UPDATE users_stg
        SET status = final_status, error_message = NULLIF(final_error_message, ''),
			user_id = new_user_id
        WHERE users_stg_id = rec.users_stg_id;
    END LOOP;

 -- Output the new_user_id value
    --RAISE NOTICE 'The new_user_id is: %', new_user_id;
	
	SELECT
        COUNT(CASE WHEN status = 'success' THEN 1 END),
        COUNT(CASE WHEN status = 'fail' THEN 1 END)
    INTO success_count, failure_count
    FROM users_stg WHERE upload_file_id = in_upload_file_id;

-- Update the count in users_file table
	UPDATE upload_file SET success_count = in_success_count,
		failure_count = in_failure_count,
		status_id = 2
		WHERE upload_file_id=in_upload_file_id;

	-- Output the counts
    RAISE NOTICE 'Success count: %, Failure count: %', success_count, failure_count;

END;
$_$;


ALTER FUNCTION public.fn_validate_users_stg(in_upload_file_id bigint) OWNER TO postgres;

--
-- Name: insert_user_with_details(text, text, text, text, text, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_user_with_details(IN in_first_name text, IN in_last_name text, IN in_email_id text, IN in_phone_number text, IN in_dob text, IN in_role_name text)
    LANGUAGE plpgsql
    AS $$
DECLARE err_state TEXT; err_message TEXT; err_detail TEXT; err_hint TEXT; err_context TEXT;
DECLARE
    new_user_id BIGINT; in_role_id BIGINT;
BEGIN
	
	-- Insert into users table
    INSERT INTO hostel.users (
        first_name, last_name, email_id, password_salt, phone_number, dob, mail_uuid, user_uuid, is_active, 
        last_login_date, last_password_reset_date, created_by_id, created_date, modified_by_id, modified_date
    )
    VALUES (
        in_first_name, in_last_name, in_email_id, NULL, in_phone_number, in_dob :: date, NULL, NULL, true,
		NULL, NULL, 1, now(), 1, now()
    )
    RETURNING user_id INTO new_user_id;

	--Get the role_id from in_role_name
	SELECT role_id FROM hostel.roles WHERE role_name = in_role_name INTO in_role_id;

    -- Insert into user_roles table
    INSERT INTO hostel.user_roles (
        user_id, role_id, is_active, created_by_id, created_date, modified_by_id, modified_date
    )
    VALUES (
        new_user_id, in_role_id,true, 1, now(), 1, now()
    );

  -- Insert into user_privileges table
    INSERT INTO hostel.user_privileges (
        user_id, resource_id, read_only_flag, read_write_flag, terminate_flag, is_active, 
        created_by_id, created_date, modified_by_id, modified_date
    )
   SELECT 
        new_user_id, rp.resource_id, rp.read_only_flag, rp.read_write_flag, rp.terminate_flag, 
        true, 1, now(), 1, now()
    FROM hostel.role_privileges rp
    WHERE rp.role_id = in_role_id;
	
	RAISE NOTICE 'RESULT : %',new_user_id;
	
EXCEPTION
    WHEN OTHERS THEN
	GET STACKED DIAGNOSTICS err_state = RETURNED_SQLSTATE,
                            err_message = MESSAGE_TEXT,
                            err_detail = PG_EXCEPTION_DETAIL,
                            err_hint = PG_EXCEPTION_HINT,
                            err_context = PG_EXCEPTION_CONTEXT;
        -- Handle the exception
        RAISE WARNING 'An error occurred: %', SQLERRM;
END;
$$;


ALTER PROCEDURE public.insert_user_with_details(IN in_first_name text, IN in_last_name text, IN in_email_id text, IN in_phone_number text, IN in_dob text, IN in_role_name text) OWNER TO postgres;

--
-- Name: nppes_file_load(bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.nppes_file_load(IN in_nppes_file_load_id bigint)
    LANGUAGE plpgsql
    AS $$
DECLARE 
    full_file_path TEXT;
    err_state TEXT; err_message TEXT; err_detail TEXT; 
	err_hint TEXT; err_context TEXT;
BEGIN
    -- DROP INDEX
    DROP INDEX IF EXISTS idx_nppes_npi_data_file_stg_npi;

    -- TRUNCATE TABLE
    TRUNCATE TABLE nppes_npi_data_file_stg;

    -- Fetch the file path dynamically based on the input parameter
    SELECT CONCAT(file_path, file_name) INTO full_file_path
    FROM nppes_file_load WHERE nppes_file_load_id = in_nppes_file_load_id;

    -- Perform the COPY command
    EXECUTE format(
        'COPY nppes_npi_data_file_stg FROM %L DELIMITER '','' CSV HEADER;',
        full_file_path);

    -- Update last_uploaded_date for the specified file load ID
    UPDATE nppes_file_load 
    SET last_uploaded_date = now() WHERE nppes_file_load_id = in_nppes_file_load_id;

    -- Create the index if it does not exist
    CREATE INDEX IF NOT EXISTS idx_nppes_npi_data_file_stg_npi
        ON public.nppes_npi_data_file_stg USING btree (npi);

    -- Log success
    RAISE NOTICE 'RESULT FILE LOAD COMPLETED: %', full_file_path;

EXCEPTION
    WHEN OTHERS THEN
        -- Capture exception details
        GET STACKED DIAGNOSTICS err_state = RETURNED_SQLSTATE,
                                err_message = MESSAGE_TEXT,
                                err_detail = PG_EXCEPTION_DETAIL,
                                err_hint = PG_EXCEPTION_HINT,
                                err_context = PG_EXCEPTION_CONTEXT;

        -- Handle the exception
        RAISE WARNING 'An error occurred: %', err_message;

        -- Optionally, log error details for debugging
        RAISE NOTICE 'Error State: %, Detail: %, Hint: %, Context: %', 
                     err_state, err_detail, err_hint, err_context;
END;
$$;


ALTER PROCEDURE public.nppes_file_load(IN in_nppes_file_load_id bigint) OWNER TO postgres;

--
-- Name: proc_validate_users_data(bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.proc_validate_users_data(IN in_upload_file_id bigint)
    LANGUAGE plpgsql
    AS $_$
	/***

-- Author	  :	Ch Sathish Kumar
-- Create date: 24-08-2024
-- Description:	validate and insert

-- EXEC SCRIPT : CALL public.proc_validate_users_data(9);

***/
DECLARE
    rec RECORD;
    email_pattern CONSTANT TEXT := '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$';
    dob_pattern CONSTANT TEXT := '^\d{4}-\d{2}-\d{2}$';
    phone_number_pattern CONSTANT TEXT := '^\d{10}$';
    final_status TEXT;
    final_error_message TEXT;
	new_user_id BIGINT;
	in_success_count BIGINT;
    in_failure_count BIGINT;
	in_upload_by_id BIGINT;
BEGIN

	SELECT uploaded_by_id INTO in_upload_by_id 
	FROM public.upload_file WHERE upload_file_id = in_upload_file_id;
	
    FOR rec IN SELECT * FROM hostel.users_file_data 
				WHERE upload_file_id = in_upload_file_id LOOP
        -- Initialize status and error message
        final_status := rec.status;
        final_error_message := COALESCE(rec.error_message, '');

        -- Check if the email exists in the users table
        IF EXISTS (SELECT 1 FROM hostel.users u WHERE u.email_id = rec.email_id) THEN
            final_status := 'fail';
            final_error_message := final_error_message || 'Email already exists, ';
        END IF;

        -- Remove trailing comma and space from error_message
        final_error_message := TRIM(BOTH ' ,' FROM final_error_message);

		--Insert into main table
		IF final_status = 'success' THEN
			SELECT fn.insrted_new_user_id INTO new_user_id FROM fn_insert_user_with_details(
			rec.first_name, rec.last_name, rec.email_id, rec.phone_number,
			rec.dob, rec.role_name,rec.is_active, in_upload_by_id) fn;
		END IF;

        -- Update the users_stg table
        UPDATE hostel.users_file_data
        SET status = final_status, error_message = NULLIF(final_error_message, ''),
			user_id = new_user_id
        WHERE users_file_data_id = rec.users_file_data_id;
	
		--Need to restet the new_user_id
		 new_user_id := NULL;
    END LOOP;

	SELECT
        COUNT(CASE WHEN status = 'success' THEN 1 END),
        COUNT(CASE WHEN status = 'fail' THEN 1 END)
    INTO in_success_count, in_failure_count
    FROM hostel.users_file_data WHERE upload_file_id = in_upload_file_id;

	-- Update the count in users_file table
	UPDATE upload_file SET success_count = in_success_count,
		failure_count = in_failure_count,
		status_id = 2
		WHERE upload_file_id=in_upload_file_id;

	-- Output the counts
    RAISE NOTICE 'Success count: %, Failure count: %', in_success_count, in_failure_count;

END;
$_$;


ALTER PROCEDURE public.proc_validate_users_data(IN in_upload_file_id bigint) OWNER TO postgres;

--
-- Name: proc_validate_users_stg(bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.proc_validate_users_stg(IN in_upload_file_id bigint)
    LANGUAGE plpgsql
    AS $_$
DECLARE
    rec RECORD;
    email_pattern CONSTANT TEXT := '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$';
    dob_pattern CONSTANT TEXT := '^\d{4}-\d{2}-\d{2}$';
    phone_number_pattern CONSTANT TEXT := '^\d{10}$';
    final_status TEXT;
    final_error_message TEXT;
	new_user_id BIGINT;
	in_success_count BIGINT;
    in_failure_count BIGINT;
BEGIN
    FOR rec IN SELECT * FROM users_stg WHERE upload_file_id = in_upload_file_id 
						AND status IS NULL	LOOP
        -- Initialize status and error message
        final_status := 'success';
        final_error_message := '';

        -- Check if the email is valid
        IF rec.email_id !~* email_pattern THEN
            final_status := 'fail';
            final_error_message := final_error_message || 'Invalid email format, ';
        END IF;

        -- Check if the email exists in the users table
        IF EXISTS (SELECT 1 FROM hostel.users u WHERE u.email_id = rec.email_id) THEN
            final_status := 'fail';
            final_error_message := final_error_message || 'Email already exists, ';
        END IF;

        -- Check if the dob is in yyyy-MM-dd format
        IF rec.dob !~* dob_pattern THEN
            final_status := 'fail';
            final_error_message := final_error_message || 'Invalid dob format, ';
        END IF;

        -- Check if the phone number is valid
        IF rec.phone_number !~* phone_number_pattern THEN
            final_status := 'fail';
            final_error_message := final_error_message || 'Invalid phone number format, ';
        END IF;

        -- Remove trailing comma and space from error_message
        final_error_message := TRIM(BOTH ' ,' FROM final_error_message);

		--Insert into main table
		IF final_status = 'success' THEN
			SELECT fn.insrted_new_user_id INTO new_user_id FROM fn_insert_user_with_details(
			rec.first_name,rec.last_name,rec.email_id,rec.phone_number,
			rec.dob,rec.role_name) fn;
		END IF;

        -- Update the users_stg table
        UPDATE users_stg
        SET status = final_status, error_message = NULLIF(final_error_message, ''),
			user_id = new_user_id
        WHERE users_stg_id = rec.users_stg_id;
	
		--Need to restet the new_user_id
		 new_user_id := NULL;
    END LOOP;

	SELECT
        COUNT(CASE WHEN status = 'success' THEN 1 END),
        COUNT(CASE WHEN status = 'fail' THEN 1 END)
    INTO in_success_count, in_failure_count
    FROM users_stg WHERE upload_file_id = in_upload_file_id;

	-- Update the count in users_file table
	UPDATE upload_file SET success_count = in_success_count,
		failure_count = in_failure_count,
		status_id = 2
		WHERE upload_file_id=in_upload_file_id;

	-- Output the counts
    RAISE NOTICE 'Success count: %, Failure count: %', in_success_count, in_failure_count;

END;
$_$;


ALTER PROCEDURE public.proc_validate_users_stg(IN in_upload_file_id bigint) OWNER TO postgres;

--
-- Name: process_json_data(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_json_data(json_input text) RETURNS TABLE(data_id integer, full_name text, email_id text)
    LANGUAGE plpgsql
    AS $$
	/**
	SELECT * FROM process_json_data('{"data_id": 1, "full_name": "", "email_id": "john.doe@example.com"}');
	*/
BEGIN
    -- Create temporary table
    CREATE TEMP TABLE temp_user (
        data_id INT,
        full_name TEXT,
        email_id TEXT
    ) ON COMMIT DROP;

    -- Insert JSON data into the temporary table
    INSERT INTO temp_user
    SELECT *
    FROM json_populate_record(NULL::temp_user, json_input::json);

    -- Return the result set from the temporary table
    RETURN QUERY SELECT * FROM temp_user;
END;
$$;


ALTER FUNCTION public.process_json_data(json_input text) OWNER TO postgres;

--
-- Name: process_json_data_set(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_json_data_set(json_input text) RETURNS TABLE(data_id integer, full_name text, email_id text)
    LANGUAGE plpgsql
    AS $$
	/**
	SELECT * FROM process_json_data_set('[
    {"data_id": 1, "full_name": "John Doe", "email_id": "john.doe@example.com"},
    {"data_id": 2, "full_name": "Jane Smith", "email_id": "jane.smith@example.com"}
		]');
	*/
BEGIN
    -- Create temporary table
    CREATE TEMP TABLE temp_users (
        data_id INT,
        full_name TEXT,
        email_id TEXT
    ) ON COMMIT DROP;

    -- Insert JSON data into the temporary table
    INSERT INTO temp_users
    SELECT *
    FROM json_populate_recordset(NULL::temp_users, json_input::json);

    -- Return the result set from the temporary table
    RETURN QUERY SELECT * FROM temp_users;
END;
$$;


ALTER FUNCTION public.process_json_data_set(json_input text) OWNER TO postgres;

--
-- Name: process_json_data_test(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.process_json_data_test(json_input text) RETURNS TABLE(id integer, name text, email text)
    LANGUAGE plpgsql
    AS $$
    /**
    SELECT * FROM process_json_data_test('{"id": 1, "name": "John Doe", "email": "john.doe@example.com"}');
    */
BEGIN
    -- Define a composite type
    CREATE TYPE temp_user_type AS (
        id INT,
        name TEXT,
        email TEXT
    );

    -- Return the result set from the temporary table
    RETURN QUERY
    SELECT * FROM json_populate_record(NULL::temp_user_type, json_input::json);

    -- Drop the composite type
   DROP TYPE temp_user_type;
END;
$$;


ALTER FUNCTION public.process_json_data_test(json_input text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: file_status; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.file_status (
    status_id integer NOT NULL,
    status character varying(25) NOT NULL,
    created_by_id bigint,
    created_date timestamp without time zone DEFAULT now(),
    modified_by_id bigint,
    modified_date timestamp without time zone DEFAULT now()
);


ALTER TABLE hostel.file_status OWNER TO postgres;

--
-- Name: hosteller_file; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.hosteller_file (
    hosteller_file_id bigint NOT NULL,
    full_name text,
    email_id text,
    phone_number text,
    fee text,
    joining_date text,
    address text,
    proof text,
    reason text,
    vacated_date text,
    active text
);


ALTER TABLE hostel.hosteller_file OWNER TO postgres;

--
-- Name: hosteller_file_hosteller_file_id_seq; Type: SEQUENCE; Schema: hostel; Owner: postgres
--

ALTER TABLE hostel.hosteller_file ALTER COLUMN hosteller_file_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hostel.hosteller_file_hosteller_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hostellers; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.hostellers (
    hosteller_id bigint NOT NULL,
    full_name character varying(250),
    email_id character varying(150) NOT NULL,
    phone_number character varying(150),
    dob date,
    fee numeric(14,2) NOT NULL,
    joining_date timestamp without time zone,
    address text,
    proof text,
    reason character varying(250),
    vacated_date timestamp without time zone,
    active boolean DEFAULT true,
    created_by_id bigint,
    created_date timestamp without time zone DEFAULT now(),
    modified_by_id bigint,
    modified_date timestamp without time zone DEFAULT now()
);


ALTER TABLE hostel.hostellers OWNER TO postgres;

--
-- Name: hostellers_hosteller_id_seq; Type: SEQUENCE; Schema: hostel; Owner: postgres
--

ALTER TABLE hostel.hostellers ALTER COLUMN hosteller_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hostel.hostellers_hosteller_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payment_history; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.payment_history (
    payment_id bigint NOT NULL,
    hosteller_id bigint NOT NULL,
    fee_paid numeric(14,2) NOT NULL,
    fee_due numeric(14,2),
    fee_date timestamp without time zone,
    payment_mode character varying(250),
    created_by_id bigint,
    created_date timestamp without time zone,
    modified_by_id bigint,
    modified_date timestamp without time zone
);


ALTER TABLE hostel.payment_history OWNER TO postgres;

--
-- Name: payment_history_payment_id_seq; Type: SEQUENCE; Schema: hostel; Owner: postgres
--

ALTER TABLE hostel.payment_history ALTER COLUMN payment_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hostel.payment_history_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: resource; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.resource (
    resource_id bigint NOT NULL,
    resource_name character varying(250),
    resource_path character varying(250),
    icon character varying(250),
    display_order bigint,
    is_subnav character(1),
    parent_name character varying(250),
    parent_icon character varying(250),
    is_active boolean
);


ALTER TABLE hostel.resource OWNER TO postgres;

--
-- Name: role_privileges; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.role_privileges (
    role_privileges_id bigint NOT NULL,
    role_id bigint,
    resource_id bigint,
    read_only_flag boolean,
    read_write_flag boolean,
    terminate_flag boolean,
    is_active boolean,
    created_by_id bigint,
    created_date timestamp without time zone,
    modified_by_id bigint,
    modified_date timestamp without time zone
);


ALTER TABLE hostel.role_privileges OWNER TO postgres;

--
-- Name: role_privileges_role_privileges_id_seq; Type: SEQUENCE; Schema: hostel; Owner: postgres
--

ALTER TABLE hostel.role_privileges ALTER COLUMN role_privileges_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hostel.role_privileges_role_privileges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: roles; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.roles (
    role_id bigint NOT NULL,
    role_name character varying(100) NOT NULL,
    is_active boolean,
    is_external_role boolean,
    note text,
    created_by_id bigint,
    created_date timestamp without time zone,
    modified_by_id bigint,
    modified_date timestamp without time zone
);


ALTER TABLE hostel.roles OWNER TO postgres;

--
-- Name: user_privileges; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.user_privileges (
    user_privileges_id bigint NOT NULL,
    user_id bigint,
    resource_id bigint,
    read_only_flag boolean,
    read_write_flag boolean,
    terminate_flag boolean,
    is_active boolean,
    created_by_id bigint,
    created_date timestamp without time zone,
    modified_by_id bigint,
    modified_date timestamp without time zone
);


ALTER TABLE hostel.user_privileges OWNER TO postgres;

--
-- Name: user_privileges_user_privileges_id_seq; Type: SEQUENCE; Schema: hostel; Owner: postgres
--

ALTER TABLE hostel.user_privileges ALTER COLUMN user_privileges_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hostel.user_privileges_user_privileges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_roles; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.user_roles (
    user_role_id bigint NOT NULL,
    user_id bigint,
    role_id bigint,
    is_active boolean,
    created_by_id bigint,
    created_date timestamp without time zone,
    modified_by_id bigint,
    modified_date timestamp without time zone
);


ALTER TABLE hostel.user_roles OWNER TO postgres;

--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE; Schema: hostel; Owner: postgres
--

ALTER TABLE hostel.user_roles ALTER COLUMN user_role_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hostel.user_roles_user_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_validation; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.user_validation (
    user_validation_id bigint NOT NULL,
    user_id bigint,
    uuid_type character varying(50),
    uuid_link character varying(50),
    is_active character(1),
    created_by_id bigint,
    created_date timestamp without time zone DEFAULT now(),
    modified_by_id bigint,
    modified_date timestamp without time zone DEFAULT now()
);


ALTER TABLE hostel.user_validation OWNER TO postgres;

--
-- Name: user_validation_user_validation_id_seq; Type: SEQUENCE; Schema: hostel; Owner: postgres
--

ALTER TABLE hostel.user_validation ALTER COLUMN user_validation_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hostel.user_validation_user_validation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.users (
    user_id bigint NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    email_id character varying(255) NOT NULL,
    password_salt character varying(255),
    phone_number character varying(50),
    dob date,
    mail_uuid character varying(150),
    user_uuid character varying(150),
    is_active boolean,
    last_login_date timestamp without time zone,
    last_password_reset_date timestamp without time zone,
    created_by_id bigint,
    created_date timestamp without time zone,
    modified_by_id bigint,
    modified_date timestamp without time zone
);


ALTER TABLE hostel.users OWNER TO postgres;

--
-- Name: users_file_data; Type: TABLE; Schema: hostel; Owner: postgres
--

CREATE TABLE hostel.users_file_data (
    users_file_data_id bigint NOT NULL,
    first_name character varying,
    last_name character varying,
    email_id character varying,
    phone_number character varying,
    dob character varying,
    role_name character varying,
    is_active character varying,
    upload_file_id bigint,
    status character varying(10),
    error_message character varying,
    user_id bigint
);


ALTER TABLE hostel.users_file_data OWNER TO postgres;

--
-- Name: users_file_data_users_file_data_id_seq; Type: SEQUENCE; Schema: hostel; Owner: postgres
--

ALTER TABLE hostel.users_file_data ALTER COLUMN users_file_data_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hostel.users_file_data_users_file_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: hostel; Owner: postgres
--

ALTER TABLE hostel.users ALTER COLUMN user_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hostel.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    id integer NOT NULL,
    employee_id integer,
    street text,
    city text,
    state text,
    zip_code text
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.address_id_seq OWNER TO postgres;

--
-- Name: address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.address_id_seq OWNED BY public.address.id;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    id integer NOT NULL,
    first_name text,
    last_name text,
    email text
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_id_seq OWNER TO postgres;

--
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_id_seq OWNED BY public.employee.id;


--
-- Name: example_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.example_table (
    example_table_id bigint NOT NULL,
    full_name character varying(100) NOT NULL,
    email_id character varying(150),
    age smallint,
    dob date,
    salary numeric(14,2) DEFAULT 0.00,
    joining_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    profile_picture bytea,
    bio text,
    preferences jsonb,
    login_attempts integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    department_id uuid NOT NULL,
    ip_address inet,
    mac_address macaddr,
    document_value xml,
    gender character(1),
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    CONSTRAINT chk_salary CHECK ((salary >= (0)::numeric)),
    CONSTRAINT example_table_age_check CHECK (((age > 0) AND (age < 120))),
    CONSTRAINT example_table_gender_check CHECK ((gender = ANY (ARRAY['M'::bpchar, 'F'::bpchar, 'O'::bpchar])))
);


ALTER TABLE public.example_table OWNER TO postgres;

--
-- Name: example_table_example_table_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.example_table ALTER COLUMN example_table_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.example_table_example_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: in_upload_by_id; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.in_upload_by_id (
    uploaded_by_id bigint
);


ALTER TABLE public.in_upload_by_id OWNER TO postgres;

--
-- Name: nppes_file_load; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nppes_file_load (
    nppes_file_load_id bigint NOT NULL,
    file_name character varying(150),
    file_type character varying(50),
    file_path character varying(150),
    uploaded_date date DEFAULT CURRENT_DATE,
    last_uploaded_date timestamp without time zone DEFAULT now()
);


ALTER TABLE public.nppes_file_load OWNER TO postgres;

--
-- Name: nppes_file_load_nppes_file_load_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.nppes_file_load ALTER COLUMN nppes_file_load_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.nppes_file_load_nppes_file_load_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: nppes_npi_data_file_stg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nppes_npi_data_file_stg (
    npi character varying,
    entity_type_code character varying,
    replacement_npi character varying,
    employer_identification_number character varying,
    provider_organization_name character varying,
    provider_last_name character varying,
    provider_first_name character varying,
    provider_middle_name character varying,
    provider_name_prefix_text character varying,
    provider_name_suffix_text character varying,
    provider_credential_text character varying,
    provider_other_organization_name character varying,
    provider_other_organization_name_type_code character varying,
    provider_other_last_name character varying,
    provider_other_first_name character varying,
    provider_other_middle_name character varying,
    provider_other_name_prefix_text character varying,
    provider_other_name_suffix_text character varying,
    provider_other_credential_text character varying,
    provider_other_last_name_type_code character varying,
    provider_first_line_business_mailing_address character varying,
    provider_second_line_business_mailing_address character varying,
    provider_business_mailing_address_city_name character varying,
    provider_business_mailing_address_state_name character varying,
    provider_business_mailing_address_postal_code character varying,
    provider_business_mailing_address_country_code character varying,
    provider_business_mailing_address_telephone_number character varying,
    provider_business_mailing_address_fax_number character varying,
    provider_first_line_business_practice_location_address character varying,
    provider_second_line_business_practice_location_address character varying,
    provider_business_practice_location_address_city_name character varying,
    provider_business_practice_location_address_state_name character varying,
    provider_business_practice_location_address_postal_code character varying,
    provider_business_practice_location_address_country_code character varying,
    provider_business_practice_location_address_telephone_number character varying,
    provider_business_practice_location_address_fax_number character varying,
    provider_enumeration_date character varying,
    last_update_date character varying,
    npi_deactivation_reason_code character varying,
    npi_deactivation_date character varying,
    npi_reactivation_date character varying,
    provider_gender_code character varying,
    authorized_official_last_name character varying,
    authorized_official_first_name character varying,
    authorized_official_middle_name character varying,
    authorized_official_title_or_position character varying,
    authorized_official_telephone_number character varying,
    healthcare_provider_taxonomy_code_1 character varying,
    provider_license_number_1 character varying,
    provider_license_number_state_code_1 character varying,
    healthcare_provider_primary_taxonomy_switch_1 character varying,
    healthcare_provider_taxonomy_code_2 character varying,
    provider_license_number_2 character varying,
    provider_license_number_state_code_2 character varying,
    healthcare_provider_primary_taxonomy_switch_2 character varying,
    healthcare_provider_taxonomy_code_3 character varying,
    provider_license_number_3 character varying,
    provider_license_number_state_code_3 character varying,
    healthcare_provider_primary_taxonomy_switch_3 character varying,
    healthcare_provider_taxonomy_code_4 character varying,
    provider_license_number_4 character varying,
    provider_license_number_state_code_4 character varying,
    healthcare_provider_primary_taxonomy_switch_4 character varying,
    healthcare_provider_taxonomy_code_5 character varying,
    provider_license_number_5 character varying,
    provider_license_number_state_code_5 character varying,
    healthcare_provider_primary_taxonomy_switch_5 character varying,
    healthcare_provider_taxonomy_code_6 character varying,
    provider_license_number_6 character varying,
    provider_license_number_state_code_6 character varying,
    healthcare_provider_primary_taxonomy_switch_6 character varying,
    healthcare_provider_taxonomy_code_7 character varying,
    provider_license_number_7 character varying,
    provider_license_number_state_code_7 character varying,
    healthcare_provider_primary_taxonomy_switch_7 character varying,
    healthcare_provider_taxonomy_code_8 character varying,
    provider_license_number_8 character varying,
    provider_license_number_state_code_8 character varying,
    healthcare_provider_primary_taxonomy_switch_8 character varying,
    healthcare_provider_taxonomy_code_9 character varying,
    provider_license_number_9 character varying,
    provider_license_number_state_code_9 character varying,
    healthcare_provider_primary_taxonomy_switch_9 character varying,
    healthcare_provider_taxonomy_code_10 character varying,
    provider_license_number_10 character varying,
    provider_license_number_state_code_10 character varying,
    healthcare_provider_primary_taxonomy_switch_10 character varying,
    healthcare_provider_taxonomy_code_11 character varying,
    provider_license_number_11 character varying,
    provider_license_number_state_code_11 character varying,
    healthcare_provider_primary_taxonomy_switch_11 character varying,
    healthcare_provider_taxonomy_code_12 character varying,
    provider_license_number_12 character varying,
    provider_license_number_state_code_12 character varying,
    healthcare_provider_primary_taxonomy_switch_12 character varying,
    healthcare_provider_taxonomy_code_13 character varying,
    provider_license_number_13 character varying,
    provider_license_number_state_code_13 character varying,
    healthcare_provider_primary_taxonomy_switch_13 character varying,
    healthcare_provider_taxonomy_code_14 character varying,
    provider_license_number_14 character varying,
    provider_license_number_state_code_14 character varying,
    healthcare_provider_primary_taxonomy_switch_14 character varying,
    healthcare_provider_taxonomy_code_15 character varying,
    provider_license_number_15 character varying,
    provider_license_number_state_code_15 character varying,
    healthcare_provider_primary_taxonomy_switch_15 character varying,
    other_provider_identifier_1 character varying,
    other_provider_identifier_type_code_1 character varying,
    other_provider_identifier_state_1 character varying,
    other_provider_identifier_issuer_1 character varying,
    other_provider_identifier_2 character varying,
    other_provider_identifier_type_code_2 character varying,
    other_provider_identifier_state_2 character varying,
    other_provider_identifier_issuer_2 character varying,
    other_provider_identifier_3 character varying,
    other_provider_identifier_type_code_3 character varying,
    other_provider_identifier_state_3 character varying,
    other_provider_identifier_issuer_3 character varying,
    other_provider_identifier_4 character varying,
    other_provider_identifier_type_code_4 character varying,
    other_provider_identifier_state_4 character varying,
    other_provider_identifier_issuer_4 character varying,
    other_provider_identifier_5 character varying,
    other_provider_identifier_type_code_5 character varying,
    other_provider_identifier_state_5 character varying,
    other_provider_identifier_issuer_5 character varying,
    other_provider_identifier_6 character varying,
    other_provider_identifier_type_code_6 character varying,
    other_provider_identifier_state_6 character varying,
    other_provider_identifier_issuer_6 character varying,
    other_provider_identifier_7 character varying,
    other_provider_identifier_type_code_7 character varying,
    other_provider_identifier_state_7 character varying,
    other_provider_identifier_issuer_7 character varying,
    other_provider_identifier_8 character varying,
    other_provider_identifier_type_code_8 character varying,
    other_provider_identifier_state_8 character varying,
    other_provider_identifier_issuer_8 character varying,
    other_provider_identifier_9 character varying,
    other_provider_identifier_type_code_9 character varying,
    other_provider_identifier_state_9 character varying,
    other_provider_identifier_issuer_9 character varying,
    other_provider_identifier_10 character varying,
    other_provider_identifier_type_code_10 character varying,
    other_provider_identifier_state_10 character varying,
    other_provider_identifier_issuer_10 character varying,
    other_provider_identifier_11 character varying,
    other_provider_identifier_type_code_11 character varying,
    other_provider_identifier_state_11 character varying,
    other_provider_identifier_issuer_11 character varying,
    other_provider_identifier_12 character varying,
    other_provider_identifier_type_code_12 character varying,
    other_provider_identifier_state_12 character varying,
    other_provider_identifier_issuer_12 character varying,
    other_provider_identifier_13 character varying,
    other_provider_identifier_type_code_13 character varying,
    other_provider_identifier_state_13 character varying,
    other_provider_identifier_issuer_13 character varying,
    other_provider_identifier_14 character varying,
    other_provider_identifier_type_code_14 character varying,
    other_provider_identifier_state_14 character varying,
    other_provider_identifier_issuer_14 character varying,
    other_provider_identifier_15 character varying,
    other_provider_identifier_type_code_15 character varying,
    other_provider_identifier_state_15 character varying,
    other_provider_identifier_issuer_15 character varying,
    other_provider_identifier_16 character varying,
    other_provider_identifier_type_code_16 character varying,
    other_provider_identifier_state_16 character varying,
    other_provider_identifier_issuer_16 character varying,
    other_provider_identifier_17 character varying,
    other_provider_identifier_type_code_17 character varying,
    other_provider_identifier_state_17 character varying,
    other_provider_identifier_issuer_17 character varying,
    other_provider_identifier_18 character varying,
    other_provider_identifier_type_code_18 character varying,
    other_provider_identifier_state_18 character varying,
    other_provider_identifier_issuer_18 character varying,
    other_provider_identifier_19 character varying,
    other_provider_identifier_type_code_19 character varying,
    other_provider_identifier_state_19 character varying,
    other_provider_identifier_issuer_19 character varying,
    other_provider_identifier_20 character varying,
    other_provider_identifier_type_code_20 character varying,
    other_provider_identifier_state_20 character varying,
    other_provider_identifier_issuer_20 character varying,
    other_provider_identifier_21 character varying,
    other_provider_identifier_type_code_21 character varying,
    other_provider_identifier_state_21 character varying,
    other_provider_identifier_issuer_21 character varying,
    other_provider_identifier_22 character varying,
    other_provider_identifier_type_code_22 character varying,
    other_provider_identifier_state_22 character varying,
    other_provider_identifier_issuer_22 character varying,
    other_provider_identifier_23 character varying,
    other_provider_identifier_type_code_23 character varying,
    other_provider_identifier_state_23 character varying,
    other_provider_identifier_issuer_23 character varying,
    other_provider_identifier_24 character varying,
    other_provider_identifier_type_code_24 character varying,
    other_provider_identifier_state_24 character varying,
    other_provider_identifier_issuer_24 character varying,
    other_provider_identifier_25 character varying,
    other_provider_identifier_type_code_25 character varying,
    other_provider_identifier_state_25 character varying,
    other_provider_identifier_issuer_25 character varying,
    other_provider_identifier_26 character varying,
    other_provider_identifier_type_code_26 character varying,
    other_provider_identifier_state_26 character varying,
    other_provider_identifier_issuer_26 character varying,
    other_provider_identifier_27 character varying,
    other_provider_identifier_type_code_27 character varying,
    other_provider_identifier_state_27 character varying,
    other_provider_identifier_issuer_27 character varying,
    other_provider_identifier_28 character varying,
    other_provider_identifier_type_code_28 character varying,
    other_provider_identifier_state_28 character varying,
    other_provider_identifier_issuer_28 character varying,
    other_provider_identifier_29 character varying,
    other_provider_identifier_type_code_29 character varying,
    other_provider_identifier_state_29 character varying,
    other_provider_identifier_issuer_29 character varying,
    other_provider_identifier_30 character varying,
    other_provider_identifier_type_code_30 character varying,
    other_provider_identifier_state_30 character varying,
    other_provider_identifier_issuer_30 character varying,
    other_provider_identifier_31 character varying,
    other_provider_identifier_type_code_31 character varying,
    other_provider_identifier_state_31 character varying,
    other_provider_identifier_issuer_31 character varying,
    other_provider_identifier_32 character varying,
    other_provider_identifier_type_code_32 character varying,
    other_provider_identifier_state_32 character varying,
    other_provider_identifier_issuer_32 character varying,
    other_provider_identifier_33 character varying,
    other_provider_identifier_type_code_33 character varying,
    other_provider_identifier_state_33 character varying,
    other_provider_identifier_issuer_33 character varying,
    other_provider_identifier_34 character varying,
    other_provider_identifier_type_code_34 character varying,
    other_provider_identifier_state_34 character varying,
    other_provider_identifier_issuer_34 character varying,
    other_provider_identifier_35 character varying,
    other_provider_identifier_type_code_35 character varying,
    other_provider_identifier_state_35 character varying,
    other_provider_identifier_issuer_35 character varying,
    other_provider_identifier_36 character varying,
    other_provider_identifier_type_code_36 character varying,
    other_provider_identifier_state_36 character varying,
    other_provider_identifier_issuer_36 character varying,
    other_provider_identifier_37 character varying,
    other_provider_identifier_type_code_37 character varying,
    other_provider_identifier_state_37 character varying,
    other_provider_identifier_issuer_37 character varying,
    other_provider_identifier_38 character varying,
    other_provider_identifier_type_code_38 character varying,
    other_provider_identifier_state_38 character varying,
    other_provider_identifier_issuer_38 character varying,
    other_provider_identifier_39 character varying,
    other_provider_identifier_type_code_39 character varying,
    other_provider_identifier_state_39 character varying,
    other_provider_identifier_issuer_39 character varying,
    other_provider_identifier_40 character varying,
    other_provider_identifier_type_code_40 character varying,
    other_provider_identifier_state_40 character varying,
    other_provider_identifier_issuer_40 character varying,
    other_provider_identifier_41 character varying,
    other_provider_identifier_type_code_41 character varying,
    other_provider_identifier_state_41 character varying,
    other_provider_identifier_issuer_41 character varying,
    other_provider_identifier_42 character varying,
    other_provider_identifier_type_code_42 character varying,
    other_provider_identifier_state_42 character varying,
    other_provider_identifier_issuer_42 character varying,
    other_provider_identifier_43 character varying,
    other_provider_identifier_type_code_43 character varying,
    other_provider_identifier_state_43 character varying,
    other_provider_identifier_issuer_43 character varying,
    other_provider_identifier_44 character varying,
    other_provider_identifier_type_code_44 character varying,
    other_provider_identifier_state_44 character varying,
    other_provider_identifier_issuer_44 character varying,
    other_provider_identifier_45 character varying,
    other_provider_identifier_type_code_45 character varying,
    other_provider_identifier_state_45 character varying,
    other_provider_identifier_issuer_45 character varying,
    other_provider_identifier_46 character varying,
    other_provider_identifier_type_code_46 character varying,
    other_provider_identifier_state_46 character varying,
    other_provider_identifier_issuer_46 character varying,
    other_provider_identifier_47 character varying,
    other_provider_identifier_type_code_47 character varying,
    other_provider_identifier_state_47 character varying,
    other_provider_identifier_issuer_47 character varying,
    other_provider_identifier_48 character varying,
    other_provider_identifier_type_code_48 character varying,
    other_provider_identifier_state_48 character varying,
    other_provider_identifier_issuer_48 character varying,
    other_provider_identifier_49 character varying,
    other_provider_identifier_type_code_49 character varying,
    other_provider_identifier_state_49 character varying,
    other_provider_identifier_issuer_49 character varying,
    other_provider_identifier_50 character varying,
    other_provider_identifier_type_code_50 character varying,
    other_provider_identifier_state_50 character varying,
    other_provider_identifier_issuer_50 character varying,
    is_sole_proprietor character varying,
    is_organization_subpart character varying,
    parent_organization_lbn character varying,
    parent_organization_tin character varying,
    authorized_official_name_prefix_text character varying,
    authorized_official_name_suffix_text character varying,
    authorized_official_credential_text character varying,
    healthcare_provider_taxonomy_group_1 character varying,
    healthcare_provider_taxonomy_group_2 character varying,
    healthcare_provider_taxonomy_group_3 character varying,
    healthcare_provider_taxonomy_group_4 character varying,
    healthcare_provider_taxonomy_group_5 character varying,
    healthcare_provider_taxonomy_group_6 character varying,
    healthcare_provider_taxonomy_group_7 character varying,
    healthcare_provider_taxonomy_group_8 character varying,
    healthcare_provider_taxonomy_group_9 character varying,
    healthcare_provider_taxonomy_group_10 character varying,
    healthcare_provider_taxonomy_group_11 character varying,
    healthcare_provider_taxonomy_group_12 character varying,
    healthcare_provider_taxonomy_group_13 character varying,
    healthcare_provider_taxonomy_group_14 character varying,
    healthcare_provider_taxonomy_group_15 character varying,
    certification_date character varying
);


ALTER TABLE public.nppes_npi_data_file_stg OWNER TO postgres;

--
-- Name: upload_file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.upload_file (
    upload_file_id bigint NOT NULL,
    file_name character varying(50),
    upload_type character varying(25),
    uploaded_by_id bigint,
    uploaded_date timestamp without time zone DEFAULT now(),
    status_id integer,
    total_count bigint,
    success_count bigint,
    failure_count bigint,
    is_mail_sent character(1) DEFAULT 'N'::bpchar
);


ALTER TABLE public.upload_file OWNER TO postgres;

--
-- Name: upload_file_upload_file_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.upload_file ALTER COLUMN upload_file_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.upload_file_upload_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_stg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_stg (
    users_stg_id bigint NOT NULL,
    first_name text,
    last_name text,
    email_id text,
    phone_number text,
    dob text,
    role_name text,
    upload_file_id bigint,
    status character varying(10),
    error_message text,
    user_id bigint
);


ALTER TABLE public.users_stg OWNER TO postgres;

--
-- Name: users_stg_users_stg_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users_stg ALTER COLUMN users_stg_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_stg_users_stg_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: address id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address ALTER COLUMN id SET DEFAULT nextval('public.address_id_seq'::regclass);


--
-- Name: employee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee ALTER COLUMN id SET DEFAULT nextval('public.employee_id_seq'::regclass);


--
-- Name: file_status file_status_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.file_status
    ADD CONSTRAINT file_status_pkey PRIMARY KEY (status_id);


--
-- Name: resource h_resource_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.resource
    ADD CONSTRAINT h_resource_pkey PRIMARY KEY (resource_id);


--
-- Name: role_privileges h_role_privileges_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.role_privileges
    ADD CONSTRAINT h_role_privileges_pkey PRIMARY KEY (role_privileges_id);


--
-- Name: roles h_roles_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.roles
    ADD CONSTRAINT h_roles_pkey PRIMARY KEY (role_id);


--
-- Name: user_privileges h_user_privileges_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.user_privileges
    ADD CONSTRAINT h_user_privileges_pkey PRIMARY KEY (user_privileges_id);


--
-- Name: user_roles h_user_roles_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.user_roles
    ADD CONSTRAINT h_user_roles_pkey PRIMARY KEY (user_role_id);


--
-- Name: user_validation h_user_validation_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.user_validation
    ADD CONSTRAINT h_user_validation_pkey PRIMARY KEY (user_validation_id);


--
-- Name: hostellers hostellers_email_id_key; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.hostellers
    ADD CONSTRAINT hostellers_email_id_key UNIQUE (email_id);


--
-- Name: hosteller_file hostellers_file_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.hosteller_file
    ADD CONSTRAINT hostellers_file_pkey PRIMARY KEY (hosteller_file_id);


--
-- Name: hostellers hostellers_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.hostellers
    ADD CONSTRAINT hostellers_pkey PRIMARY KEY (hosteller_id);


--
-- Name: payment_history payment_history_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.payment_history
    ADD CONSTRAINT payment_history_pkey PRIMARY KEY (payment_id);


--
-- Name: users users_email_id_key; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.users
    ADD CONSTRAINT users_email_id_key UNIQUE (email_id);


--
-- Name: users_file_data users_file_data_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.users_file_data
    ADD CONSTRAINT users_file_data_pkey PRIMARY KEY (users_file_data_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: hostel; Owner: postgres
--

ALTER TABLE ONLY hostel.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (id);


--
-- Name: example_table pk_example_table_example_table_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.example_table
    ADD CONSTRAINT pk_example_table_example_table_id PRIMARY KEY (example_table_id);


--
-- Name: nppes_file_load pk_nppes_file_load_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nppes_file_load
    ADD CONSTRAINT pk_nppes_file_load_id PRIMARY KEY (nppes_file_load_id);


--
-- Name: example_table uk_example_table_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.example_table
    ADD CONSTRAINT uk_example_table_email UNIQUE (email_id);


--
-- Name: upload_file users_file_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upload_file
    ADD CONSTRAINT users_file_pk PRIMARY KEY (upload_file_id);


--
-- Name: users_stg users_stg_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_stg
    ADD CONSTRAINT users_stg_pk PRIMARY KEY (users_stg_id);


--
-- Name: idx_nppes_npi_data_file_stg_npi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_nppes_npi_data_file_stg_npi ON public.nppes_npi_data_file_stg USING btree (npi);


--
-- Name: address address_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employee(id);


--
-- PostgreSQL database dump complete
--

